package com.rustui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

public class RustButton extends Button {
    /** 0..1, driven by the screen for the slide-in animation. */
    public float appear = 1f;
    private float hover;
    private long last;

    public RustButton(int x, int y, int w, int h, Component label, OnPress onPress) {
        super(x, y, w, h, label, onPress, DEFAULT_NARRATION);
    }

    @Override
    public void renderContents(GuiGraphics g, int mouseX, int mouseY, float delta) {
        long now = Util.getMillis();
        float dt = last == 0 ? 16f : Math.min(100f, now - last);
        last = now;
        boolean hot = this.isHoveredOrFocused();
        hover += ((hot ? 1f : 0f) - hover) * Math.min(1f, dt / 70f);

        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        if (appear < 0.04f) return;

        int fw = (int) (w * RustTheme.ease(hover));
        if (fw > 0) {
            g.fill(x, y, x + fw, y + h, RustTheme.a(0xCD412B, appear));
            g.fill(x, y, x + 2, y + h, RustTheme.a(0xFFFFFF, appear));
        }
        var font = Minecraft.getInstance().font;
        int rgb = hover > 0.5f ? 0xFFFFFF : 0xE6E6E6;
        g.drawString(font, RustTheme.bold(getMessage().getString()),
                x + 10 + (int) (4 * hover), y + (h - 8) / 2, RustTheme.a(rgb, appear));
    }
}

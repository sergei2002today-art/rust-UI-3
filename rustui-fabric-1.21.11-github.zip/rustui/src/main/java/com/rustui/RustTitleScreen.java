package com.rustui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

public class RustTitleScreen extends Screen {
    private static final int BASE_X = 18;
    private final long openTime = Util.getMillis();
    private final List<RustButton> buttons = new ArrayList<>();

    public RustTitleScreen() {
        super(Component.translatable("narrator.screen.title"));
    }

    private void add(int y, Component label, Button.OnPress press) {
        RustButton b = new RustButton(BASE_X, y, 176, 16, label, press);
        buttons.add(b);
        addRenderableWidget(b);
    }

    @Override
    protected void init() {
        buttons.clear();
        // same vertical rhythm as the Rust main menu: PLAY / group / SETTINGS / QUIT
        add((int) (height * 0.353), Component.translatable("menu.singleplayer"), b -> minecraft.setScreen(new SelectWorldScreen(this)));
        add((int) (height * 0.462), Component.translatable("menu.multiplayer"), b -> minecraft.setScreen(new JoinMultiplayerScreen(this)));
        add((int) (height * 0.756), Component.translatable("menu.options"), b -> minecraft.setScreen(new OptionsScreen(this, minecraft.options)));
        add((int) (height * 0.868), Component.translatable("menu.quit"), b -> minecraft.stop());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        long el = Util.getMillis() - openTime;
        for (int i = 0; i < buttons.size(); i++) {
            float e = RustTheme.ease((el - 250 - i * 110) / 500f);
            RustButton b = buttons.get(i);
            b.appear = e;
            b.setX(BASE_X - (int) (36 * (1f - e)));
        }
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
        long el = Util.getMillis() - openTime;
        RustTheme.drawTitleBackground(g, width, height);
        // y=46 keeps the logo under the launcher's on-screen Esc button
        RustTheme.drawLogo(g, font, 28, 46, RustTheme.ease(el / 700f));
        RustTheme.drawSideIcons(g, width, RustTheme.ease((el - 500) / 900f));
        float black = 1f - RustTheme.ease(el / 450f);
        if (black > 0.01f) g.fill(0, 0, width, height, RustTheme.a(0x000000, black));
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
